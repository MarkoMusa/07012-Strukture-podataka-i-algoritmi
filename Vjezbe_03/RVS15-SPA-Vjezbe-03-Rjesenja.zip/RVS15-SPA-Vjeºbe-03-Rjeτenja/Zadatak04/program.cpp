#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "lista_poljem.h"
using namespace std;

int main() {
	lista_poljem lista;

	ifstream dat("Life_expectancy.csv");
	if (!dat) {
		cout << "Greska prilikom otvaranja datoteke" << endl;
		return 1;
	}

	stringstream sstr;
	string temp;
	getline(dat, temp);

	while (true) {
		sstr.str("");
		sstr.clear();
		ELTYPE zapis;

		if (!getline(dat, zapis.drzava, ';')) { // Naziv.
			break;
		}
		
		getline(dat, temp, ';'); // O�ekivanje u stringu.
		sstr << temp;
		if (!(sstr >> zapis.ocekivanje)) { // O�ekivanje u doubleu.
			zapis.ocekivanje = 0;
		}

		getline(dat, temp); // Odbacimo sve do kraja retka.

		if (!lista.insert(zapis, lista.end())) {
			cout << "Greska prilikom umetanja u listu" << endl;
			return 2;
		}
	}
	dat.close();
	
	double ukupno = 0;
	double n = 0;
	for (POSITION i = lista.first(); i != lista.end(); i = lista.next(i)) {
		ELTYPE element;
		if (lista.read(i, element)) {
			if (element.ocekivanje > 0) {
				ukupno += element.ocekivanje;
				n++;
			}
		}		
	}
	
	cout << "Prosjecna svjetska ocekivana zivotna dob: " << ukupno / n << endl;

	string trazeni_naziv;
	bool dalje;
	do {
		cout << "Upisite naziv drzave: ";
		getline(cin, trazeni_naziv);

		POSITION found_pos = lista.find(trazeni_naziv);
		if (found_pos != lista.end()) {
			ELTYPE found_elem;
			lista.read(found_pos, found_elem);
			if (found_elem.ocekivanje > 0) {
				cout << "Ocekivana zivotna dob je: " << found_elem.ocekivanje << endl;
			}
			else {
				cout << "Za trazenu drzavu nema dostupnih podataka o ocekivanoj zivotnoj dobi" << endl;
			}
		}
		else {
			cout << "Trazena drzava ne postoji u listi" << endl;
		}

		cout << "Dalje (1 = da, 0 = ne): ";
		cin >> dalje;
		cin.ignore();
	} while (dalje);

	return 0;
}