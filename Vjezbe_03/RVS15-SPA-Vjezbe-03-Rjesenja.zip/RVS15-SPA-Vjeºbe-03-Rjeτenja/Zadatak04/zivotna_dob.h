#ifndef _ZIVOTNA_DOB_H
#define _ZIVOTNA_DOB_H

#include <iostream>
#include <string>
using namespace std;

struct zivotna_dob {
	string drzava;
	double ocekivanje;
};

#endif
