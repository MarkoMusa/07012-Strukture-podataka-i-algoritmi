#include <iostream>
#include <string>
#include <fstream>
#include "lista_poljem.h"
using namespace std;

int main() {
	lista_poljem lista;

	ifstream dat("brojevi.txt");
	if (!dat) {
		cout << "Greska prilikom otvaranja datoteke" << endl;
		return 1;
	}

	int broj;
	while (dat >> broj) {
		if (!lista.insert(broj, lista.end())) {
			cout << "Greska prilikom umetanja u listu" << endl;
			return 2;
		}
	}
	
	bool dalje;
	int trazeni_broj;
	do {
		cout << "Unesite broj koji trazite: ";
		cin >> trazeni_broj;
		if (lista.find(trazeni_broj) != lista.end()) {
			cout << "Trazeni broj postoji" << endl;
		}
		else {
			cout << "Trazeni broj ne postoji" << endl;
		}

		cout << "Dalje (0 = ne, 1 = da): ";
		cin >> dalje;
	} while (dalje);

	dat.close();
	return 0;
}