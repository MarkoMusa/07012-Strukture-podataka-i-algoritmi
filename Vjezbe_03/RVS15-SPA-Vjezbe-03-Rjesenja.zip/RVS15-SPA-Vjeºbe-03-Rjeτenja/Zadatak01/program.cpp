#include <iostream>
#include <string>
#include <fstream>
#include "lista_poljem.h"
using namespace std;

int main() {
	lista_poljem lista;

	ifstream dat("brojevi.txt");
	if (!dat) {
		cout << "Greska prilikom otvaranja datoteke" << endl;
		return 1;
	}

	int broj;
	while (dat >> broj) {
		if (!lista.insert(broj, lista.end())) {
			cout << "Greska prilikom umetanja u listu" << endl;
			return 2;
		}
	}
	
	ELTYPE element;
	long long zbroj = 0;
	int n = 0;
	for (POSITION i = lista.first(); i < lista.end(); i = lista.next(i)) {
		if (lista.read(i, element)) {
			zbroj += element;
			n++;
		}
	}

	cout << "Prosjek je: " << fixed << (double)zbroj / n << endl;

	dat.close();
	return 0;
}