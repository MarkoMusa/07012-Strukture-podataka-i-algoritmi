#ifndef _LISTA_POLJEM_H_
#define _LISTA_POLJEM_H_

#include <string>
#include "zivotna_dob.h"
using namespace std;

typedef unsigned int POSITION;
typedef zivotna_dob ELTYPE;

class lista_poljem {
private:
	static const unsigned int CAPACITY = 500;
	ELTYPE _elements[CAPACITY];
	POSITION _last; // Pozicija zadnjeg elementa liste (odmah ispred mjesta "prvo iza").

public:
	lista_poljem();
	POSITION end();
	POSITION first();
	bool insert(ELTYPE element, POSITION pos);
	bool read(POSITION pos, ELTYPE& element);
	bool remove(POSITION pos);
	POSITION find(string naziv_drzave);
	POSITION find(double min_ocekivana_vrijednost);
	POSITION empty();
	POSITION next(POSITION pos);
	POSITION prev(POSITION pos);
};

#endif