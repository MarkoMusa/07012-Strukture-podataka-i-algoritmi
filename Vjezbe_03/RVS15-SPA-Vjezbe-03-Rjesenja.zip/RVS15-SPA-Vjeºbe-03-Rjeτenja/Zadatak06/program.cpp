#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "lista_poljem.h"
using namespace std;

void ucitaj_u_listu(lista_poljem& lista, string datoteka, int& error);

int main() {
	lista_poljem lista(500);
	
	int error;
	ucitaj_u_listu(lista, "Life_expectancy.csv", error);
	if (error != 0) {
		return error;
	}

	double min_dob;
	cout << "Upisite minimalnu zeljenu dob: ";
	cin >> min_dob;

	POSITION found_pos;
	while (true) {
		found_pos = lista.find(min_dob);
		if (found_pos != lista.end()) {
			lista.remove(found_pos);
		}
		else {
			break;
		}
	}

	for (POSITION i = lista.first(); i < lista.end(); i = lista.next(i)) {
		ELTYPE element;
		if (lista.read(i, element)) {
			cout << element.drzava  << " (" << element.ocekivanje << ")" << endl;
		}
	}

	return 0;
}

void ucitaj_u_listu(lista_poljem& lista, string datoteka, int& error) {
	ifstream dat(datoteka);
	if (!dat) {
		cout << "Greska prilikom otvaranja datoteke" << endl;
		error = 1;
		return;
	}

	stringstream sstr;
	string temp;
	getline(dat, temp);

	while (true) {
		sstr.str("");
		sstr.clear();
		ELTYPE zapis;

		if (!getline(dat, zapis.drzava, ';')) { // Naziv.
			break;
		}
		
		getline(dat, temp, ';'); // O�ekivanje u stringu.
		sstr << temp;
		if (!(sstr >> zapis.ocekivanje)) { // O�ekivanje u doubleu.
			zapis.ocekivanje = 0;
		}

		getline(dat, temp); // Odbacimo sve do kraja retka.

		if (!lista.insert(zapis, lista.end())) {
			cout << "Greska prilikom umetanja u listu" << endl;
			error = 2;
			return;
		}
	}

	dat.close();
	error = 0;
}