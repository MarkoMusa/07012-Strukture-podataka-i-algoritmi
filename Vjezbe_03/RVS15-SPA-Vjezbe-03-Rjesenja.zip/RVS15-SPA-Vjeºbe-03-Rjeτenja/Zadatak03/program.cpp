#include <iostream>
#include <string>
#include <fstream>
#include "lista_poljem.h"
using namespace std;

int main() {
	lista_poljem lista;

	ifstream dat("brojevi.txt");
	if (!dat) {
		cout << "Greska prilikom otvaranja datoteke" << endl;
		return 1;
	}

	int broj;
	while (dat >> broj) {
		if (!lista.insert(broj, lista.end())) {
			cout << "Greska prilikom umetanja u listu" << endl;
			return 2;
		}
	}
	
	cout << "Broj elemenata u listi: " << lista.length() << endl;

	dat.close();
	return 0;
}