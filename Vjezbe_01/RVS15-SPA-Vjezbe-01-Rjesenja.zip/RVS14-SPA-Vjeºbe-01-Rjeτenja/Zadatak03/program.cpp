#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include "emisija_drzave.h"
using namespace std;

double dohvati_emisiju(ifstream& dat, bool zadnji) {
	char separator = ';';
	if (zadnji) {
		separator = '\n';
	}

	string temp;
	getline(dat, temp, separator);

	double rezultat;
	stringstream sstr;
	sstr << temp;
	if (sstr >> rezultat) {
		return rezultat;
	}
	return 0;
}

int main() {
	vector<emisija_drzave> emisije;

	ifstream dat("Co2_emisije.csv");
	if (!dat) {
		cout << "Ne mogu otvoriti datoteku Co2_emisije.csv" << endl;
		return 1;
	}

	double em;
	string temp;
	getline(dat, temp); // Odbacim prvu liniju sa zaglavljem.
	while (true) {
		emisija_drzave emisija;
		if (!getline(dat, emisija.naziv, ';')) { // Ako ne u�itam naziv dr�ave, zna�i da vi�e nema ni�ega.
			break;
		}

		getline(dat, emisija.sifra, ';');

		// Slijede mi podaci za 48 godina iza kojih dolazi ';'.
		for (int i = 0; i < 48; i++) {
			em = dohvati_emisiju(dat, false);
			emisija.emisija += em;
		}

		// Iza podatka za zadnju godinu mi dolazi enter.
		em = dohvati_emisiju(dat, true);
		emisija.emisija += em;

		emisije.push_back(emisija);
	}

	dat.close();

	for (int i = 0; i < emisije.size(); i++) {
		cout << emisije[i].naziv << ": " << emisije[i].emisija << endl;
	}
	return 0;
}