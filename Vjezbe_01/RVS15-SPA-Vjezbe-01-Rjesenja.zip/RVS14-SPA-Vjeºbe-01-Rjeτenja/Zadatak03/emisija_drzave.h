#ifndef _EMISIJA_DRZAVE_H_
#define _EMISIJA_DRZAVE_H_

#include <string>
using namespace std;

struct emisija_drzave {
	string naziv;
	string sifra;
	double emisija;
	emisija_drzave() {
		emisija = 0;
	}
};

#endif