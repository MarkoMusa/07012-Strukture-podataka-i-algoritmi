#include <iostream>
#include <fstream>
#include "pravokutnik.h"
using namespace std;

void ucitaj(pravokutnik* pravokutnici, int n) {
	for (int i = 0; i < n; i++) {
		cout << "Sirina: ";
		cin >> pravokutnici[i].sirina;
		cout << "Visina: ";
		cin >> pravokutnici[i].visina;
	}
}

void ispisi(pravokutnik* pravokutnici, int n, ofstream& dat) {
	for (int i = 0; i < n; i++) {
		dat << "P(" << pravokutnici[i].sirina << ", " << pravokutnici[i].visina << ") = " << pravokutnici[i].sirina * pravokutnici[i].visina << endl;
	}
}

int main() {
	pravokutnik pravokutnici[5];
	ucitaj(pravokutnici, 5);

	ofstream dat("pravokutnici.txt");
	if (!dat) {
		cout << "Ne mogu otvoriti datoteku" << endl;
		return 1;
	}

	ispisi(pravokutnici, 5, dat);

	dat.close();

	return 0;
}