#ifndef _PRAVOKUTNIK_H_
#define _PRAVOKUTNIK_H_

struct pravokutnik {
	int sirina;
	int visina;
};

#endif
