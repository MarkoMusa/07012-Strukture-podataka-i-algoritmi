#ifndef _RAZLOMAK_H_
#define _RAZLOMAK_H_

#include <string>
using namespace std;

class razlomak {
private:
	int _brojnik;
	int _nazivnik;
public:
	razlomak(int brojnik, int nazivnik);
	string to_string();
	void pomnozi(int n);
};

#endif