#include <iostream>
#include <fstream>
#include "razlomak.h"
using namespace std;

int main() {
	bool dalje;
	int brojnik, nazivnik, skalar;
	do {
		cout << "Upisite brojnik: ";
		cin >> brojnik;
		cout << "Upisite nazivnik: ";
		cin >> nazivnik;
		cout << "Upisite skalar: ";
		cin >> skalar;

		razlomak r(brojnik, nazivnik);
		cout << r.to_string() << " * " << skalar << " = ";
		r.pomnozi(skalar);
		cout << r.to_string() << endl;

		cout << "Dalje (1/0): ";
		cin >> dalje;

	} while (dalje);

	return 0;
}