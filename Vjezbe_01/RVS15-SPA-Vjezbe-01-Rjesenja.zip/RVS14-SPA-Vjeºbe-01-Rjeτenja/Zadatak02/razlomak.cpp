#include <sstream>
#include <string>
#include "razlomak.h"
using namespace std;

razlomak::razlomak(int brojnik, int nazivnik) {
	this->_brojnik = brojnik;
	this->_nazivnik = nazivnik;
}

string razlomak::to_string() {
	stringstream s;
	s << this->_brojnik << "/" << this->_nazivnik;
	return s.str();
}

void razlomak::pomnozi(int n) {
	this->_brojnik *= n;
}