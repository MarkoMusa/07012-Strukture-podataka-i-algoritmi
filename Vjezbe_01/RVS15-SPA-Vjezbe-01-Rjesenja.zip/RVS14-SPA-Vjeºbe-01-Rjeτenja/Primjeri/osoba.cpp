#include <string>
#include <iostream>
#include <sstream>
#include "osoba.h"
using namespace std;

osoba::osoba(string ime, string prezime, string oib) {
	this->ime = ime;
	this->prezime = prezime;
	this->oib = oib;
}

string osoba::pretvori_u_string() {
	stringstream sstr;

	sstr << prezime << ", " << ime << " (" << oib << ")";

	return sstr.str();
}