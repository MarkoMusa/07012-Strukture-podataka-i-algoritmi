#ifndef _OSOBA_H_
#define _OSOBA_H_

#include <iostream>
#include <string>
using namespace std;

class osoba {
private:
	string ime;
	string prezime;
	string oib;
public:
	osoba(string ime, string prezime, string oib);
	string pretvori_u_string();
};

#endif