#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include "osoba.h"
using namespace std;

int main() {
	// Primjer 1.
	osoba o("Miro", "Miric", "333333333335");
	cout << o.pretvori_u_string() << endl;

	// Primjer 2.
	ifstream emisije("Co2_emisije.csv");
	if (!emisije) {
		cout << "Greska pri otvaranju datoteke Co2_emisije.csv" << endl;
		return 1;
	}

	string buffer;

	// Pro�itamo prvi redak i odbacimo ga.
	getline(emisije, buffer);

	// Iz drugog retka pro�itamo naziv dr�ave i ispi�emo ga.
	getline(emisije, buffer, ';');
	cout << "Drzava: " << buffer << endl;

	// Pro�itamo kratki naziv dr�ave i ispi�emo ga.
	getline(emisije, buffer, ';');
	cout << "Kratki naziv: " << buffer << endl;

	stringstream sstr;
	double zbroj = 0;
	for (int i = 0; i < 3; i++) {
		getline(emisije, buffer, ';');
		sstr << buffer;
		double d;
		if (sstr >> d) {
			zbroj += d;
		}
		
		sstr.str("");
		sstr.clear();
	}
	cout << "Emisija: " << zbroj << endl;

	emisije.close();

	// Primjer 3.
	ifstream banke("banke.bin", ios_base::binary);
	if (!emisije) {
		cout << "Greska pri otvaranju datoteke Co2_emisije.csv" << endl;
		return 1;
	}

	short n;
	banke.read((char*)(&n), sizeof(n));

	char* znakovi = new char[n];
	banke.read(znakovi, n);
	string naziv_banke(znakovi, n);
	delete[] znakovi;

	znakovi = new char[n];
	banke.read(znakovi, 7);
	string vbdi(znakovi, 7);
	delete[] znakovi;

	cout << "Banka: " << naziv_banke << endl;
	cout << "VBDI: " << vbdi << endl;

	banke.close();

	return 0;
}