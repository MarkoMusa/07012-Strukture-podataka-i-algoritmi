#ifndef _BANKA_H_
#define _BANKA_H_

#include <string>
using namespace std;

struct banka {
	string naziv;
	string vbdi;
};

#endif