#include <iostream>
#include <vector>
#include <string>
#include <fstream>
#include <sstream>
#include "banka.h"
using namespace std;

string procitaj_string(ifstream& dat, int duljina) {
	char* temp = new char[duljina];
	dat.read(temp, duljina);
	string s(temp, duljina);
	delete[] temp;
	return s;
}

int main() {
	vector<banka> banke;

	ifstream dat("banke.bin", ios_base::binary);
	if (!dat) {
		cout << "Ne mogu otvoriti datoteku banke.bin" << endl;
		return 1;
	}

	while (true) {
		banka b;

		short n;
		dat.read((char*)(&n), sizeof(n));
		if (!dat) {
			break;
		}

		b.naziv = procitaj_string(dat, n);
		b.vbdi = procitaj_string(dat, 7);
		
		banke.push_back(b);
	}

	dat.close();

	for (int i = 0; i < banke.size(); i++) {
		cout << banke[i].naziv << " (" << banke[i].vbdi << ")" << endl;
	}
	return 0;
}